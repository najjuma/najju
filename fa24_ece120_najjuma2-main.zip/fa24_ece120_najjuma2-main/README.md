# ECE 120 (fa24) repo for NetID: najjuma2

GitHub username at initialization time: najjuma-wange

For next steps, please refer to the instructions provided by your course.
