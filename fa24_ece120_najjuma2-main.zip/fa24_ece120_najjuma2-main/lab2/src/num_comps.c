#include <stdio.h>
int main() {
    int val1 = -22;
    int val2 = 33;
    int res;

    res = val1 * val2;

    printf("%d\n", res);

    return 0;
}