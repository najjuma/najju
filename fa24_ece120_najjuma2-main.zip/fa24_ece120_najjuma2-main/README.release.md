# ECE 120 (fa24)

This file was created automatically as a placeholder in the shared `.release` repo for the course.

For next steps, please refer to the instructions provided by your course.

**Note:** In order to avoid unnecessary merge conflicts with student repos, this file has been intentionally named `README.release.md` instead of `README.md`. We recommend that staff not rename this file.